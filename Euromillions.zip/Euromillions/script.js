const uniqueNumbers = [];
while (uniqueNumbers.length < 5) {
    let newNumber = Math.ceil(Math.random() * 50);
    if (uniqueNumbers.indexOf(newNumber) == -1) {
        uniqueNumbers.push(newNumber);
    }
}
console.log(uniqueNumbers);